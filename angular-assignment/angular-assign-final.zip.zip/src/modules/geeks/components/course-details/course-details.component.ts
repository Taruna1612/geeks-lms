import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'course-details',
    templateUrl: './course-details.component.html',
    styleUrls: ['./course-details.component.css']
  })
  export class CourseDetailsComponent implements OnInit {
    ngOnInit(): void {
        
    }
}