// const express = require('express');
// const app = express();
const URL = "https://apikey-v2-31rq8eya20ziu6vfftxaboal92cgpvbl2vq0j08l8dh:f86c63bfb03f4a04b44d3b2ecedcf49a@67dd6035-bf98-418c-be35-ac85d3e8e0ce-bluemix.cloudantnosqldb.appdomain.cloud";
const username = "apikey-v2-31rq8eya20ziu6vfftxaboal92cgpvbl2vq0j08l8dh";
const password = "f86c63bfb03f4a04b44d3b2ecedcf49a";
const apiKey = "boV71oLvwmeABwkO009UAd2aiBVUuIJqSzr8K9pi2-tw";
let docs;
let allCourses = [];
const Cloudant = require('@cloudant/cloudant');
// const cloudant = Cloudant({url: URL, username: username, password: password});
const cloudant = Cloudant({url: URL, apikey:apiKey });
const db = cloudant.db.use('all-courses');
const main = async() => {    
    const data = await db.get("_design/getAllCourses/_view/new-view");   
    for(let i in data.rows){
        allCourses.push(data.rows[i].value);
    }
    return allCourses;
}

main().then((data) => {app.get("/allCourses", (req,res)=>{
    console.log(data);
    res.json(data);
})});

